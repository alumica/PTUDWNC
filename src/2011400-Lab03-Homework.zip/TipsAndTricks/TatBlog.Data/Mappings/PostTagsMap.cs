﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TatBlog.Core.Entities;

namespace TatBlog.Data.Mappings
{
    //public class PostTagsMap : IEntityTypeConfiguration<PostTags>
    //{
    //    public void Configure(EntityTypeBuilder<PostTags> builder)
    //    {
    //        builder.ToTable("Posts");

            
    //    }
    //}

    public class PostTagsMap
    {

    }
}
